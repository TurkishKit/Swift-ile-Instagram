import UIKit
import PlaygroundSupport
/*:
 ## Profil Fotoğrafı 👩‍💻👨‍💻
 
 Profil fotoğrafı, hesabınıza girip giremeyen herkesin gördüğü, küçük, daire şeklinde bir fotoğraftır.
 
 Bu fotoğrafı kodlamak için öncellikle bilgisayara bir fotoğraf olduğunu tanımlamanız gerekecektir. Tanımladıktan sonra içine bir profil fotoğrafı yerleştirip bu fotoğrafı yuvarlak bir şekle getirebilirsiniz.
*/
let profilFotografiView = TKImageView(position: (10,12), size: (32,32), image: UIImage.profileImage)

profilFotografiView.isRounded = true
/*:
 * Callout(Not🖋):
 Profil fotoğrafını *ImageView* olarak tanımlamanızın nedeni şeklini düzenleyebilmek içindir.
 */

//: [Header View](@previous) | Sayfa 3 | [Kullanıcı Adı](@next)
