import Foundation
import UIKit


/// Profil fotoğrafımız
public var profileImage = UIImage.profileImage

/// Kullanıcı Adımız
public var username = "turkishkit"

/// Paylaşım Lokasyonumuz
public var location = "Workinton"

/// Gönderi ile paylaştığımız fotoğraf(lar)
public var postImages = [UIImage.postImage1, UIImage.postImage2, UIImage.postImage3]

/// Gönderimize gelen beğeni sayısı
public var likeCount = 38

/// Gönderimize gelen yorum sayısı
public var commentCount = 21

/// Gönderimizin altına yazdığımız yazı
public var postCaption = "Burada, sizlerle olmak harika! #tkozeletkinligi"

public let footerView = FooterView(position: (0, bodyView.bottom + 0), caption: postCaption, numberOfLikes: likeCount, numberOfComments: commentCount)

public let bodyView = BodyView(position: (0, headerView.bottom + 0), photos: postImages)

public let headerView = HeaderView(position: (0, 0), profileImage: profileImage, username: username, location: location)
