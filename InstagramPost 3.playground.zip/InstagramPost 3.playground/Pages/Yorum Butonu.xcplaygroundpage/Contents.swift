import UIKit
import PlaygroundSupport
/*:
 ## Yorum Butonu 💬
 Yorum butonu gönderiye yorumlarınızı atmak için kullanılır. Bu yorumlar takip eden tüm kullanıcılar tarafından görülür.
 
 Yorum butonunu *TKButton* olarak tanımlayıp içine fotoğrafını yerleştiriniz.
*/
let yorumButonu = TKButton(position: (0,0), size: (40,40))
yorumButonu.normalImage = UIImage.commentIcon
//: [Beğeni Butonu](@previous) | Sayfa 11 | [Gönder Butonu](@next)

