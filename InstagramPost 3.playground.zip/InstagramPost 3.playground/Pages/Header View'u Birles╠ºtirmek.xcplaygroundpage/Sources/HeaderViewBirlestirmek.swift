import Foundation
import UIKit

public var profilFotografiView = UIImage.profileImage
public var kullaniciAdiLabel = "turkishkit"
public var konumLabel = "Workinton"
public var seceneklerButonu = UIImage.moreIcon
