import UIKit
import PlaygroundSupport
/*:
 ## Yaptıklarınızı Header View'da Birleştirin!📱
 
 Post sayfanızın ilk kısmını tamamladınız!😄🎉
 
 Tanımladığınız elemanları *headerView* kısmı oluşturarak hep bir arada görmek ister misiniz?
 
 Bunu yapmak için ilk olarak hepsini bir arada tutacak *headerView* adlı bir kısım oluşturmanız gerekecektir.
 
 HeaderView'un pozisyonunu ayarlamanız da gerekecektir.
*/

let headerView = HeaderView(position: (0, 0), profileImage: profilFotografiView, username: kullaniciAdiLabel, location: konumLabel)

//: [Seçenekler Butonu](@previous) | Sayfa 7 | [Body View](@next)
