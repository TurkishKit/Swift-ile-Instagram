/*:
 ## Gönder Butonu ✉️
 Gönder butonu takipçilerinize bu postu göndermek için vardır. Gönderdiğiniz post diğer kullanıcıların mesajlarına gitmektedir.
 
 Gönder butonunuzu tanımlamak için onu *TKButton*'ın içine tanımlayınız.
*/
let gonderButonu = TKButton(position: (0,0), size: (40,40))
//: [Yorum Butonu](@previous) | Sayfa 12 | [Kaydet Butonu](@next)
