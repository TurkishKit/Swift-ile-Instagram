import PlaygroundSupport
import UIKit
/*:
 ## Footer View'u Birleştirmek
 Postunuzun en son kısmı olan Footer View'un elemanlarını kodlamayı bitirdiniz!
 
 Bütün elemanları *FooterView* oluşturarak birleştiriniz.
*/
let footerView = FooterView(position: (0, 0), caption: gonderiYorumuLabel, numberOfLikes: begeniSayisi, numberOfComments: yorumSayisi)
//: [Bütün Yorumları Gör](@previous) | Sayfa 20 | [İnstagram Sayfası](@next)
