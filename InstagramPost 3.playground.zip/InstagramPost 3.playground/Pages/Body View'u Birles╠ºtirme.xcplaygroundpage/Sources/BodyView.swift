import Foundation
import UIKit

public let fotograf1 = UIImage.postImage1
public let fotograf2 = UIImage.postImage2
public let fotograf3 = UIImage.postImage3
