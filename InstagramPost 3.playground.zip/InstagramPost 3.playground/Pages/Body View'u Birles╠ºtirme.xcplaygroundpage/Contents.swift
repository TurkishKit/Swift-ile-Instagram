import UIKit
import PlaygroundSupport
/*:
 ## Body View'u Birleştirme 📱
 Body View'un elemanlarını kodlamayınız bitirdiniz!
 
 Kodladıklarınız hep birlikte bir tane Body View altında görmek ister misiniz?
 
 Bunun için, *BodyView* alanı oluşturmanız gerekecektir.
*/
let bodyView = BodyView(position: (0,0), photos: [fotograf1, fotograf2, fotograf3])

//: [Sayfa Kontrolü](@previous) | Sayfa 15 | [Footer View](@next)
