import UIKit
import PlaygroundSupport
/*:
 ## Gönderi Yorumu 🏷
 Gönderi yorumunuz, fotoğraflarınız altına yaptığınız küçük açıklamalardır. Bu açıklamaların arasında kendi düşünceniz ve hastag bulunur. Diğer kullanıcılar yorum atsa da fotoğrafın sahibinin yorumu her zaman görünür.
 
 Gönderinizin yorumunu *TKLabel*'ın içine tanımlayınız.
 */
let gonderiYorumuLabel = TKLabel(position: (0,0), size: (100, 40))
/*:
* Callout(#hashtag):
 Hashtagleriniz mavi renkte ve kalın fontta olmalıdır!
 */
let hashtag = TKLabel()
hashtag.text = "#tkozeletkinligi"
hashtag.changeFont(size: 12, style: .semibold, color: .instaBlue)
/*:
 Gönderi yorumunuzu *gonderiYorumuLabel*'ın içine yazınız ve sonuna da hashtaginizi ekleyiniz.
 */
gonderiYorumuLabel.text = "Burada, sizlerle olmak harika! \(hashtag)"
//:[Beğeni Sayısı](@previous) | Sayfa 18 | [Bütün Yorumları Gör](@next)
