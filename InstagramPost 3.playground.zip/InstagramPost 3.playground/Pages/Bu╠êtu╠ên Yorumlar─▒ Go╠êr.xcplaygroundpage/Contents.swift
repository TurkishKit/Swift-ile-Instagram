import UIKit
import PlaygroundSupport
/*:
 ## Bütün Yorumları Gör 🔎
 Bütün yorumları gör kısmında gönderinizin kaç tane yorum aldığını görebilirsiniz. Bu kısım çok çarpıcı olmamakla beraber daha açık renklidir. Başka bir kullanıcı yorum attığında bütün yorumları gör kısmındaki toplam yorum sayısı değişmektedir.
 
 * Callout(Dikkat etmeniz gereken özellikler):
    * *Label*'ın açık gri renkte olması
    * Yorum sayısı için bir değişkeninizin olması
 
 Öncellikle bütün yorumları görmek amacıyla *TKLabel* oluşturmanız gerekecektir. Aynı zamanda *butunYorumlariGorLabel*'ının rengini ve fontunu da ayarlayınız.
 */
let butunYorumlariGorLabel = TKLabel(position: (0,0), size: (100,40))
butunYorumlariGorLabel.changeFont(size: 13.0, style: .regular, color: .instaLightGray)
/*:
 Yorum sayısını belirlemek için bir değişken oluşturunuz.
 */
let yorumSayisi = 21
/*:
 *butunYorumlariGorLabel*'ınızın içindeki yazıyı belirleyiniz.
 */
butunYorumlariGorLabel.text = "View all \(yorumSayisi) comments"
//: [Gönderi Yorumu](@previous) | Sayfa 19 | [Footer View'u Birleştirmek](@next)
