/*:

 ## Header View
 Header View, post sayfasında en yukarıda bulunan, çeşitli bilgileri barındıran bir kısımdır.
 
 ### Header View'un içindekiler:
 * Profil fotoğrafı
 * Kullanıcı adı
 * Lokasyon bilgisi
 * More butonu

[Başlangıç Sayfası](@previous) | Sayfa 2 | [Profil Fotoğrafı](@next)
*/
