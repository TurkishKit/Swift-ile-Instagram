/*:
 # Playground ile Instagram Oturumuna Hoşgeldiniz!
 ### Bu oturumda Apple'ın Playground platformlarını kullanarak bir instagram gönderi sayfası yapabileceksiniz.
 
 ## Öğrenecekleriniz:
 * **HeaderView**
 * **BodyView**
 * **FooterView**
 * **Instagram Postunu Görüntüleme**
 
  | Sayfa 1 | [Header View](@next)
 */
