import UIKit
import PlaygroundSupport
/*:
 ## Fotoğraflar 📸
 Bir instagram gönderisinin en önemli kısmı, o gönderinin fotoğraflarıdır. Birkaç tane fotoğraf bir arada da konulabilir ve fotoğraflar arasında geçiş yapılabilir.
 
 Öncellikle fotoğraflarınızı bir *UIImage* olarak tanımlayınız.
 
 Sonradan hepsini tek bir değişkenin içine atayınız, bu onların arka arkaya dizilmesine neden olacak ve fotoğraflar arası geçişi mümkün edecektir.
 
 * Callout(Tip💡):
 Fotoğrafları tanımlarken birden fazla resim olduğundan array kullanınız.
 */

let fotograf1 = UIImage.postImage1
let fotograf2 = UIImage.postImage2
let fotograf3 = UIImage.postImage3
let postImages = [fotograf1, fotograf2, fotograf3]

//: [Body View](@previous) | Sayfa 9 | [Beğeni Butonu](@next)
